CKEDITOR.editorConfig = function(config) {
  config.extraPlugins = 'footnotes,lineutils,widget,clipboard,dialog,dialogui';
}
